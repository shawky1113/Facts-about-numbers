package com.example.numbers

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
