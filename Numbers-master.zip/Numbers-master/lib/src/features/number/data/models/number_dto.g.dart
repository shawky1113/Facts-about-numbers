// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'number_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_NumberDto _$$_NumberDtoFromJson(Map<String, dynamic> json) => _$_NumberDto(
      info: json['info'] as String,
    );

Map<String, dynamic> _$$_NumberDtoToJson(_$_NumberDto instance) =>
    <String, dynamic>{
      'info': instance.info,
    };
