final class Url {
  const Url._();

  static const numbersApi = 'http://numbersapi.com';
}
