final class Path {
  const Path._();

  static const numberPage = '/';
  static const settingsPage = 'settings';
}
