import 'package:numbers/src/core/core.dart';

final class GetThemeParams extends Params {
  const GetThemeParams({required this.key});

  final String key;
}
