import 'package:numbers/src/core/core.dart';

final class GetNumberParams extends Params {
  const GetNumberParams({required this.number});

  final int number;
}
