import 'package:numbers/bootstrap.dart';
import 'package:numbers/src/app/app.dart';

void main() {
  bootstrap(() => const App());
}
